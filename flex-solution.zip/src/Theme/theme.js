export const TitleName = "Flex Solutions";
export const Sologan = "Celebrations done right";
export const Subtitle = "We Provide best Comparison service in the whole universe"